import "./style/style.css";
import "./script/view/script.js";
import "./script/view/box-layanan.js";
import "./script/view/card-layanan.js";
import main from "./script/data/data-source.js";

main();