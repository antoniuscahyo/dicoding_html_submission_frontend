class BoxLayanan extends HTMLElement {

    
 
}
 
customElements.define("box-layanan", BoxLayanan);